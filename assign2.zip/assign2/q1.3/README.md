# Distributed_systems_projects
Course work projects and assignment @IIIT Hyderabad 
# Matrix Chain Multiplication Benchmarking

This project implements a parallelized Matrix Chain Multiplication (MCM) algorithm using MPI, designed for scalability and performance benchmarking on HPC clusters managed by SLURM.

---

## 🚀 Features

- Modular MPI-based implementation
- Dynamic programming with distributed updates
- SLURM-compatible job scripts
- Performance logging and CSV output
- Scalability analysis (speedup, efficiency)

---

## 📁 Directory Structure

mcm_project/
├── main.py # MPI driver for MCM 
├── utils.py # Utility functions for timing and logging 
├── dp_table.py
├── input_handler.py
├── mcm_solver.py
├── performace.py
├── input/ │ └── input_mcm.txt # Input file: number of matrices + dimensions 
├── output/ │ ├── performance_results.csv # Timing and profiling data │ ├── out_<jobid>.txt # SLURM stdout logs │ └── err_<jobid>.txt # SLURM stderr logs 
├── run_main.slurm # SLURM job submission script
├── submit_scalling.sh
└── README.md # Project documentation


---

## 🧠 Problem Description

Given a sequence of matrices, the goal is to determine the optimal parenthesization that minimizes the total number of scalar multiplications. This implementation distributes the dynamic programming table across MPI ranks and synchronizes updates using collective communication.

---

## ⚙️ System Setup

 Activate environment.yml
 conda env create-f environment.yml
---

## 🛠️ How to Run

### 1. Prepare Input
Edit `input/input_mcm.txt` with:
### 2.Start Experiment: 
 bash submit_scaling.sh

check generated output file for output :) or errors :(
