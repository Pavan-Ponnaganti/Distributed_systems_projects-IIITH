import math

def initialize_dp_table(N):
    return [[0 if i == j else math.inf for j in range(N+1)] for i in range(N+1)]

