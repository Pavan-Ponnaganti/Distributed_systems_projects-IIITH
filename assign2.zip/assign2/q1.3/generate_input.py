import random

def generate_matrix_chain_file(filename, n, min_dim=1, max_dim=100):
    """
    Generates a matrix chain input file.

    Args:
    filename (str): Path to output file
    n (int): Number of matrices
    min_dim (int): Minimum dimension value
    max_dim (int): Maximum dimension value
    """
    # Create n+1 dimensions for n matrices
    dimensions = [random.randint(min_dim, max_dim) for _ in range(n + 1)]

    # Write to file
    with open(filename, 'w') as f:
        f.write(f"{n}\n")
        f.write(' '.join(map(str, dimensions)) + '\n')

if __name__ == "__main__":
    n = int(input("Enter the number of matrices: "))
    file_name = "input_mcm.txt"
    generate_matrix_chain_file(file_name, n)
    print(f"Matrix chain input file '{file_name}' generated.")

