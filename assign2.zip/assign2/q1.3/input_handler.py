import sys

def read_and_broadcast_input(comm, rank):
    dims, N = None, None
    if rank == 0:
        if len(sys.argv) < 2:
            print("Usage: python main.py <dims_file>", file=sys.stderr)
            sys.exit(1)
        with open(sys.argv[1], "r") as f:
            lines = f.readlines()
            N = int(lines[0].strip())
            dims = list(map(int, lines[1].split()))
    dims = comm.bcast(dims, root=0)
    N = comm.bcast(N, root=0)
    return dims, N

