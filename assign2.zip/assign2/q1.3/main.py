from mpi4py import MPI
from input_handler import read_and_broadcast_input
from dp_table import initialize_dp_table
from mcm_solver import run_parallel_mcm
from performance import gather_and_log_performance

comm = MPI.COMM_WORLD
rank = comm.Get_rank()
size = comm.Get_size()

dims, N = read_and_broadcast_input(comm, rank)
dp = initialize_dp_table(N)

result, comp_time, comm_time, total_time = run_parallel_mcm(dp, dims, N, comm, rank, size)
gather_and_log_performance(comm, rank, size, dp, N, comp_time, comm_time, total_time)

