from mpi4py import MPI
from utils import chunk_indices, compute_cost

def run_parallel_mcm(dp, dims, N, comm, rank, size):
    global_start = MPI.Wtime()
    comp_time = 0.0
    comm_time = 0.0

    for L in range(2, N+1):
        count = N - L + 1
        start, end = chunk_indices(count, size, rank)

        t1 = MPI.Wtime()
        local_updates = {}
        for rel in range(start, end):
            i = 1 + rel
            j = i + L - 1
            best = float('inf')
            for k in range(i, j):
                cost = compute_cost(dp, dims, i, k, j)
                if cost < best:
                    best = cost
            local_updates[(i, j)] = best
        t2 = MPI.Wtime()
        comp_time += (t2 - t1)

        t3 = MPI.Wtime()
        all_updates = comm.allgather(local_updates)
        t4 = MPI.Wtime()
        comm_time += (t4 - t3)

        for updates in all_updates:
            for (i, j), val in updates.items():
                dp[i][j] = val

    total_time = MPI.Wtime() - global_start
    result = dp[1][N]
    return result, comp_time, comm_time, total_time

