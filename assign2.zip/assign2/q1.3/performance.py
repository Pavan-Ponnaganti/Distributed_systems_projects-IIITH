from utils import write_csv_row

def gather_and_log_performance(comm, rank, size, dp, N, comp_time, comm_time, total_time):
    stats = (rank, comp_time, comm_time, total_time)
    all_stats = comm.gather(stats, root=0)

    if rank == 0:
        result = dp[1][N]
        print(f"p={size} | result={result} | total={total_time:.6f}s")

        comp_sum = sum(s[1] for s in all_stats)
        comm_sum = sum(s[2] for s in all_stats)
        comp_max = max(s[1] for s in all_stats)
        comm_max = max(s[2] for s in all_stats)

        write_csv_row("output/performance_results.csv", size, total_time, comp_sum, comm_sum, comp_max, comm_max)

