#!/bin/bash
MAX_CORES=96
STEP=4

for ntasks in $(seq $STEP $STEP $MAX_CORES); do
    echo "Submitting scaling job with $ntasks tasks"
    sbatch --ntasks=$ntasks --cpus-per-task=1 run_main.slurm
    sleep 1
done

