def compute_cost(dp, dims, i, k, j):
    return dp[i][k] + dp[k+1][j] + dims[i-1] * dims[k] * dims[j]

def chunk_indices(count, size, rank):
    chunk = (count + size - 1) // size
    start = rank * chunk
    end = min(start + chunk, count)
    return start, end

def write_csv_row(filename, size, total_time, comp_sum, comm_sum, comp_max, comm_max):
    with open(filename, "a") as f:
        f.write(f"{size},{total_time:.6f},{comp_sum:.6f},{comm_sum:.6f},{comp_max:.6f},{comm_max:.6f}\n")

