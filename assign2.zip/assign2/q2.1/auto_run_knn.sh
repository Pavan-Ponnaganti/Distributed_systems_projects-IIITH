#!/bin/bash

DATA_DIR="./data"
POINTS_FILE=$(find "$DATA_DIR" -name "points.csv" | head -n 1)
QUERIES_FILE=$(find "$DATA_DIR" -name "queries.csv" | head -n 1)
OUTPUT_DIR="./output"

if [ -z "$POINTS_FILE" ] || [ -z "$QUERIES_FILE" ]; then
  echo "❌ Could not find points.csv or queries.csv in $DATA_DIR"
  exit 1
fi

echo "📁 Found input files:"
echo "   Points:  $POINTS_FILE"
echo "   Queries: $QUERIES_FILE"
echo "   Output:  $OUTPUT_DIR"

# Ask user for K value
read -p "🔢 Enter the value of K (number of nearest neighbors): " K

# Validate K is a positive integer
if ! [[ "$K" =~ ^[0-9]+$ ]] || [ "$K" -le 0 ]; then
  echo "❌ Invalid value for K. Please enter a positive integer."
  exit 1
fi

# Submit the SLURM job
sbatch run_knn_mpr.sh "$POINTS_FILE" "$QUERIES_FILE" "$K" "$OUTPUT_DIR"

