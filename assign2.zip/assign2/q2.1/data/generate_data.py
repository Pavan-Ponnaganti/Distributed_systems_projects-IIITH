
import numpy as np
import argparse

# Parse input argument for 'x'
parser = argparse.ArgumentParser(description="Generate test data for KNN.")
parser.add_argument('x', type=int, help="Base number of points")
args = parser.parse_args()
x = args.x

# Generate 2D points: 10x points
num_points = 10 * x
points = np.random.rand(num_points, 2) * 100  # Scale to 0-100
np.savetxt('points.csv', points, delimiter=',')

# Generate query points: x points
queries = np.random.rand(x, 2) * 100
np.savetxt('queries.csv', queries, delimiter=',')

print(f"Generated {num_points} points and {x} query points.")
print("Files 'points.csv' and 'queries.csv' have been created without headers.")

