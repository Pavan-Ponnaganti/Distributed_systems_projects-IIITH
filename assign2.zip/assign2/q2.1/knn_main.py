from mpi4py import MPI
import sys
from map import setup_phase, mapper
from shuffle import shuffler
from reduce import reducer, gather_results
from output import finalize_output, write_timings

def load_csv(fname):
    data = []
    with open(fname) as f:
        for line in f:
            x, y = line.strip().split(",")
            data.append((float(x), float(y)))
    return data

def distributed_knn(points, queries, K, output_dir):
    comm = MPI.COMM_WORLD
    rank = comm.Get_rank()
    size = comm.Get_size()
    timings = {}
    t_start = MPI.Wtime()

    # Setup
    t0 = MPI.Wtime()
    xmin, ymin, xmax, ymax, cell_size = setup_phase(points, K, comm, rank)
    timings["setup"] = MPI.Wtime() - t0

    # Map
    t0 = MPI.Wtime()
    local_points = points[rank::size]
    local_queries = queries[rank::size]
    mapped = mapper(local_points, local_queries, xmin, ymin, cell_size)
    timings["map"] = MPI.Wtime() - t0

    # Shuffle
    t0 = MPI.Wtime()
    buckets = shuffler(mapped, comm, size)
    timings["shuffle"] = MPI.Wtime() - t0

    # Reduce
    t0 = MPI.Wtime()
    results = reducer(buckets, K)
    timings["reduce"] = MPI.Wtime() - t0

    # Gather
    t0 = MPI.Wtime()
    gathered = gather_results(results, comm, rank)
    timings["gather"] = MPI.Wtime() - t0
    timings["total"] = MPI.Wtime() - t_start

    timings_max = {k: comm.reduce(v, op=MPI.MAX, root=0) for k, v in timings.items()}

    if rank == 0:
        finalize_output(gathered, K, output_dir)
        write_timings(timings_max, output_dir)
        print(f"✅ Results written to {output_dir}/results.txt")
        print(f"⏱️ Timings written to {output_dir}/timings.txt")

if __name__ == "__main__":
    comm = MPI.COMM_WORLD
    rank = comm.Get_rank()
    if len(sys.argv) < 5:
        if rank == 0:
            print("Usage: mpirun -np P python knn_main.py points.csv queries.csv K output_dir")
        sys.exit(0)

    points_file, queries_file, K, output_dir = sys.argv[1], sys.argv[2], int(sys.argv[3]), sys.argv[4]
    points = load_csv(points_file)
    queries = load_csv(queries_file)
    distributed_knn(points, queries, K, output_dir)

