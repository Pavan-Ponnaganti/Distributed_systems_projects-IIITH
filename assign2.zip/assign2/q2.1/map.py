from mpi4py import MPI
import random, math

def sample_points(points, sample_size=10000):
    return random.sample(points, min(len(points), sample_size))

def estimate_dk(points_sample, K):
    dists = []
    for i, p in enumerate(points_sample):
        distances = []
        for j, q in enumerate(points_sample):
            if i != j:
                dx = p[0] - q[0]
                dy = p[1] - q[1]
                distances.append(math.sqrt(dx * dx + dy * dy))
        distances.sort()
        if len(distances) >= K:
            dists.append(distances[K - 1])
    return sum(dists) / len(dists) if dists else 1.0

def get_cell(x, y, xmin, ymin, cell_size):
    cell_x = int((x - xmin) / cell_size)
    cell_y = int((y - ymin) / cell_size)
    return (cell_x, cell_y)

def setup_phase(points, K, comm, rank):
    if rank == 0:
        xmin = min(p[0] for p in points)
        ymin = min(p[1] for p in points)
        xmax = max(p[0] for p in points)
        ymax = max(p[1] for p in points)
        sample = sample_points(points, 1000)
        dK = estimate_dk(sample, K)
        cell_size = 1.2 * dK
    else:
        xmin = ymin = xmax = ymax = cell_size = None

    return comm.bcast((xmin, ymin, xmax, ymax, cell_size), root=0)

def mapper(points, queries, xmin, ymin, cell_size):
    mapped = []
    for p in points:
        cell = get_cell(p[0], p[1], xmin, ymin, cell_size)
        mapped.append((cell, "P", p))

    for q in queries:
        qcell = get_cell(q[0], q[1], xmin, ymin, cell_size)
        for dx in [-1, 0, 1]:
            for dy in [-1, 0, 1]:
                mapped.append(((qcell[0] + dx, qcell[1] + dy), "Q", q))
    return mapped

