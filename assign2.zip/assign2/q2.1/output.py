import os

def finalize_output(gathered, K, output_dir):
    final = {}
    for part in gathered:
        for q, neigh in part:
            if q not in final:
                final[q] = []
            final[q].extend(neigh)

    for q in final:
        final[q].sort(key=lambda x: x[0])
        final[q] = final[q][:K]

    os.makedirs(output_dir, exist_ok=True)
    with open(os.path.join(output_dir, "results.txt"), "w") as f:
        for q, neigh in final.items():
            neigh_str = " ".join([f"({p[0]},{p[1]})" for _, p in neigh])
            f.write(f"Query {q}: {neigh_str}\n")

def write_timings(timings_max, output_dir):
    with open(os.path.join(output_dir, "timings.txt"), "w") as f:
        for k, v in timings_max.items():
            f.write(f"{k}: {v:.6f}\n")

