import math
from mpi4py import MPI

def reducer(buckets, K):
    results = []
    for cell, group in buckets.items():
        points_here = group["P"]
        queries_here = group["Q"]
        for q in queries_here:
            neighbors = []
            for p in points_here:
                dx = q[0] - p[0]
                dy = q[1] - p[1]
                dist = math.sqrt(dx * dx + dy * dy)
                neighbors.append((dist, p))
            neighbors.sort(key=lambda x: x[0])
            results.append((q, neighbors[:K]))
    return results

def gather_results(results, comm, rank):
    return comm.gather(results, root=0)

