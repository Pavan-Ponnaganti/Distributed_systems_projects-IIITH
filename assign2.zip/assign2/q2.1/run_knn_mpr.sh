#!/bin/bash
#SBATCH --job-name=knn_scaling
#SBATCH --partition=debug
#SBATCH --time=01:00:00
#SBATCH --ntasks=96
#SBATCH --output=scaling_out_%j.txt
#SBATCH --error=scaling_err_%j.txt

# Load Python environment
module load python
source ~/miniconda3/etc/profile.d/conda.sh
conda activate mpr_env

if [ $# -lt 4 ]; then
  echo "Usage: ./run_knn_mpr.sh points.csv queries.csv K output_dir"
  exit 1
fi

POINTS_FILE=$1
QUERIES_FILE=$2
K=$3
OUTPUT_DIR=$4

mkdir -p "$OUTPUT_DIR"
RESULTS_CSV="$OUTPUT_DIR/scaling_results.csv"

echo "procs,setup,map,shuffle,reduce,gather,total" > "$RESULTS_CSV"

for P in $(seq 4 4 96); do
    echo "🔹 Running with $P processes..."
    RUN_DIR="$OUTPUT_DIR/run_$P"
    mkdir -p "$RUN_DIR"

    mpiexec -n $P python knn_main.py "$POINTS_FILE" "$QUERIES_FILE" "$K" "$RUN_DIR"

    SETUP=$(grep "setup:"   "$RUN_DIR/timings.txt" | awk '{print $2}')
    MAP=$(grep "map:"       "$RUN_DIR/timings.txt" | awk '{print $2}')
    SHUFFLE=$(grep "shuffle:" "$RUN_DIR/timings.txt" | awk '{print $2}')
    REDUCE=$(grep "reduce:" "$RUN_DIR/timings.txt" | awk '{print $2}')
    GATHER=$(grep "gather:" "$RUN_DIR/timings.txt" | awk '{print $2}')
    TOTAL=$(grep "total:"   "$RUN_DIR/timings.txt" | awk '{print $2}')

    echo "$P,$SETUP,$MAP,$SHUFFLE,$REDUCE,$GATHER,$TOTAL" >> "$RESULTS_CSV"
done

echo "✅ Scaling experiment finished. Results saved in $RESULTS_CSV"

