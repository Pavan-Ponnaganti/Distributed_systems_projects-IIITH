from mpi4py import MPI

def shuffler(mapped, comm, size):
    send_data = [[] for _ in range(size)]
    for cell, rtype, data in mapped:
        dest = hash(cell) % size
        send_data[dest].append((cell, rtype, data))

    recv_data = comm.alltoall(send_data)
    flat = [item for sublist in recv_data for item in sublist]

    buckets = {}
    for cell, rtype, data in flat:
        if cell not in buckets:
            buckets[cell] = {"P": [], "Q": []}
        buckets[cell][rtype].append(data)
    return buckets

