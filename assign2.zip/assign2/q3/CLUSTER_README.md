# gRPC Monitoring System - Remote Cluster Setup Guide

## RCE Cluster Access Credentials
- **Username**: cs3401.03
- **Password**: SXvr1SrQ
- **SSH Access**: `ssh cs3401.03@rce.iiit.ac.in`
- **Available Cores**: 96 cores (shared resource)
- **Cluster Type**: SLURM cluster

## Prerequisites and Setup

### 1. Connect to RCE Cluster
```bash
# From IIIT network or VPN
ssh cs3401.03@rce.iiit.ac.in
```

### 2. Load Required Modules
```bash
# Load gRPC module
module load gRPC/1.74.1

# Load Python module (if needed)
module load Python/3.9.6-GCCcore-11.2.0

# Check available modules
module avail

# List loaded modules
module list
```

### 3. Setup Python Environment
```bash
# Create virtual environment
# I did it without setting up the environment
python -m venv grpc_env
source grpc_env/bin/activate

# Install required packages
pip install grpcio grpcio-tools
```

### 4. Upload Project Files
```bash
# From your local machine, upload files to cluster
scp -r /path/to/your/project cs3401.03@rce.iiit.ac.in:~/q3/

## Project Structure
```
grpc_monitoring/
├── server.py
├── client.py
├── monitoring.proto
├── monitoring_pb2.py
├── monitoring_pb2_grpc.py
├── users.text
├── jobs.txt
├── requirements.txt
└── logs/
``

## Running on SLURM Cluster

### Option 1: Single Server with Multiple Clients

#### Step 1: Allocate Resources
```bash
# Allocate 2 nodes for 30 minutes with 11 tasks total
salloc --nodes=2 --ntasks=11 --time=00:30:00

# Check allocated nodes
squeue -u cs3401.03
```

#### Step 2: Start Server
```bash
# SSH to first allocated node (replace nodeXXX with actual node)
ssh nodeXXX

# Navigate to project directory
cd ~/grpc_monitoring

# Load modules
module load gRPC/1.74.1
module load Python/3.9.6-GCCcore-11.2.0

# Activate virtual environment
source ~/grpc_env/bin/activate

# Start server on specific port
python server.py &

# # Or with custom port
# python -c "
# import server
# import logging
# logging.basicConfig(level=logging.INFO)
# server.serve(port=50053)
# " &

# # Note the server's IP address
# hostname -I
```

#### Step 3: Run Clients from Another Node
```bash
# SSH to second allocated node
ssh nodeYYY

# Navigate to project directory
cd ~/q3

# Load modules
module load gRPC/1.74.1
module load Python/3.9.6-GCCcore-11.2.0
# source ~/grpc_env/bin/activate

# Create log directory
mkdir -p client_logs

# Single client test
python client.py --host <server_node_ip> --port 50053 --rpc all

# Multiple clients with srun
srun -n10 -o client_logs/client_%t.out python client.py --host <server_node_ip> --port 50053 --rpc all

## Useful SLURM Commands

### Job Management
```bash
# Check job queue
squeue -u cs3401.03

# Check running jobs
squeue -u cs3401.03 --states=RUNNING

# Cancel specific job
scancel <job_id>

# Cancel all your jobs
scancel -u cs3401.03

# Job details
scontrol show job <job_id>

# Node information
sinfo -N
```

## Networking and Connectivity

### Find Node IP Addresses
```bash
# Get IP of current node
hostname -I

# Get IP of specific node
ssh nodeXXX 'hostname -I'

# Alternative method
getent hosts nodeXXX
```

## Troubleshooting

### Common Issues and Solutions

#### 1. Module Load Failures
```bash
# If gRPC module not found, check available versions
module avail grpc
module avail gRPC

# Load compatible version
module load gRPC/1.60.0  # or available version
```

#### 2. Python Package Issues
```bash
# Reinstall packages
pip uninstall grpcio grpcio-tools
pip install grpcio==1.60.0 grpcio-tools==1.60.0

# Check installed packages
pip list | grep grpc
```

#### 3. Connection Issues
```bash
# Check if server is running
ps aux | grep python

# Check server logs
tail -f server_*.out

# Test local connection first
python client.py --host localhost --rpc list_users
```

#### 4. File Access Issues
```bash
# Ensure data files exist
ls -la users.text jobs.txt

# Check file permissions
chmod 644 users.text jobs.txt
```

## Quick Start Commands
```bash
# 1. Connect and setup
ssh cs3401.03@rce.iiit.ac.in
module load gRPC/1.74.1 Python/3.9.6-GCCcore-11.2.0

# 2. Allocate resources
salloc --nodes=2 --ntasks=11 --time=00:30:00

# 3. Start server (on node1)
ssh node001
python server.py 

# 4. Run clients (on node2)
ssh node002
srun -n10 python client.py --host <node001_ip> --rpc all

# 5. Clean up
scancel -u cs3401.03
```

Replace `<server_node_ip>`, `<node001_ip>`, etc., with actual IP addresses from your allocated nodes.
