# monitoring_client.py
import grpc
import json
import monitoring_pb2
import argparse
import monitoring_pb2_grpc
import time
import threading
from concurrent.futures import ThreadPoolExecutor

def message_to_dict(message):
    """Convert protobuf message to dictionary"""
    if hasattr(message, 'users'):  # Handle UserResponse
        return {
            'users': [user.username for user in message.users]  # Only usernames
        }
    else:  # Handle Job message
        return {
            'id': message.id,
            'name': message.name,
            'owner': message.owner,
            'start_time_iso': message.start_time_iso,
            'runtime_seconds': message.runtime_seconds
        }

def call_list_users(stub):
    """Call ListUsers RPC"""
    print("=== ListUsers ===")
    response = stub.ListUsers(monitoring_pb2.Empty())
    json_response = message_to_dict(response)
    print(json.dumps(json_response, indent=2))
    return json_response

def call_list_jobs(stub):
    """Call ListJobs streaming RPC"""
    print("=== ListJobs (Streaming) ===")
    jobs = []
    for job in stub.ListJobs(monitoring_pb2.Empty()):
        json_job = message_to_dict(job)
        jobs.append(json_job)
        print(f"Job: {json_job['name']} (Runtime: {json_job['runtime_seconds']}s)")
    return jobs

def call_longest_job(stub):
    """Call GetLongestRunningJob RPC"""
    print("=== Longest Running Job ===")
    response = stub.GetLongestRunningJob(monitoring_pb2.Empty())
    json_response = message_to_dict(response)
    print(json.dumps(json_response, indent=2))
    return json_response

def test_concurrent_clients(host, port, num_clients=5):
    """Test multiple clients calling the server concurrently"""
    print(f"=== Testing {num_clients} Concurrent Clients ===")
    
    def run_client(client_id):
        """Run a single client"""
        target = f"{host}:{port}"
        try:
            with grpc.insecure_channel(target) as channel:
                stub = monitoring_pb2_grpc.MonitoringStub(channel)
                
                # Each client calls a different RPC
                if client_id % 3 == 0:
                    result = call_list_users(stub)
                elif client_id % 3 == 1:
                    result = call_list_jobs(stub)
                else:
                    result = call_longest_job(stub)
                
                print(f"Client {client_id} completed successfully")
                return True
        except Exception as e:
            print(f"Client {client_id} failed: {e}")
            return False
    
    # Run clients concurrently
    with ThreadPoolExecutor(max_workers=num_clients) as executor:
        futures = [executor.submit(run_client, i) for i in range(num_clients)]
        
        # Wait for all to complete
        results = [future.result() for future in futures]
    
    successful = sum(results)
    print(f"Concurrent test completed: {successful}/{num_clients} clients successful")

def main():
    parser = argparse.ArgumentParser(description="gRPC Monitoring Client")
    parser.add_argument("--host", default="localhost", help="Server hostname or IP")
    parser.add_argument("--port", type=int, default=50051, help="Server port")
    parser.add_argument("--rpc", choices=["list_users", "list_jobs", "longest", "all", "concurrent"], 
                       default="all", help="RPC method to call")
    parser.add_argument("--concurrent-clients", type=int, default=5, 
                       help="Number of concurrent clients for concurrent test")
    args = parser.parse_args()

    target = f"{args.host}:{args.port}"
    print(f"Connecting to: {target}")
    
    if args.rpc == "concurrent":
        test_concurrent_clients(args.host, args.port, args.concurrent_clients)
        return
    
    # Single client connection
    try:
        with grpc.insecure_channel(target) as channel:
            stub = monitoring_pb2_grpc.MonitoringStub(channel)
            
            if args.rpc == "list_users":
                call_list_users(stub)
            elif args.rpc == "list_jobs":
                call_list_jobs(stub)
            elif args.rpc == "longest":
                call_longest_job(stub)
            else:  # all
                call_list_users(stub)
                print()
                call_list_jobs(stub)
                print()
                call_longest_job(stub)
                
    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    main()
