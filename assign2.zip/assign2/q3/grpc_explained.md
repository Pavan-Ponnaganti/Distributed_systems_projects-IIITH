## 🔄 gRPC Communication Flow

### Step-by-Step Process:

```
CLIENT NODE                         NETWORK                           SERVER NODE
─────────────                      ─────────                         ───────────

1. client.py calls:
   stub.ListUsers(Empty())
           │
           ▼
2. MonitoringStub serializes 
   Empty() → bytes
           │
           ▼                        
3. gRPC sends HTTP/2 request  ────────────────►  4. gRPC server receives
   to server_ip:50051                              HTTP/2 request
                                                           │
                                                           ▼
                                                   5. Server deserializes
                                                      bytes → Empty()
                                                           │
                                                           ▼
                                                   6. Calls YOUR method:
                                                      servicer.ListUsers(request, context)
                                                           │
                                                           ▼
                                                   7. Your code runs:
                                                      - reads users.text
                                                      - creates UsersResponse
                                                      - returns it
                                                           │
                                                           ▼
                                                   8. gRPC serializes
                                                      UsersResponse → bytes
                                                           │
                                                           ▼
9. Client deserializes       ◄────────────────  10. Sends HTTP/2 response
   bytes → UsersResponse                           back to client
           │
           ▼
10. Your client gets the
    UsersResponse object
```

### Key Points:
- **HTTP/2 over TCP**: gRPC uses this for actual network communication
- **Protobuf Serialization**: Converts your objects to bytes and back
- **Method Routing**: gRPC knows which method to call based on URL path
- **Error Handling**: gRPC handles network errors, timeouts, etc.
