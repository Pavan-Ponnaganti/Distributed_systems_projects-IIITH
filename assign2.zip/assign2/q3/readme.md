## server

salloc --nodes=2 --ntasks=11 --time=00:30:00
ssh node{node_number1}

python server.py  // port 50053

## client

ssh node{node_number2}
# single client
python client.py --host {server_node_ip} --rpc all  
# multiple clients
mkdir -p client_log

srun -n10 -o client_log/client_%t.out python client.py --rpc all

// for multiple clients it can work if both the server and the client node have the same ip that is on the same machine as it will be our defualt ip = localhost

if not then we can use the below command to specify the ip address of the client node

srun -n10 -o client_log/client_%t.out python client.py --host {server_ip} --rpc all

Additional Commands
scancel --cs3401.03