# monitoring_server.py
import grpc
from concurrent import futures
import time
import logging
from datetime import datetime, timezone
import os

import monitoring_pb2
import monitoring_pb2_grpc

# Paths for simulated input files (same directory)
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
USERS_FILE = os.path.join(BASE_DIR, "users.text")
JOBS_FILE = os.path.join(BASE_DIR, "jobs.txt")


def parse_iso_time(s: str) -> datetime:
    # Accept ISO strings; if no tzinfo, assume UTC
    dt = datetime.fromisoformat(s)
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt


def current_utc():
    return datetime.now(timezone.utc)


class MonitoringServicer(monitoring_pb2_grpc.MonitoringServicer):
    def __init__(self, users_file=USERS_FILE, jobs_file=JOBS_FILE):
        self.users_file = users_file
        self.jobs_file = jobs_file

    def _read_users(self):
        """Read users from file"""
        users = []
        
        if not os.path.exists(self.users_file):
            logging.error(f"Users file not found: {self.users_file}")
            return users
            
        with open(self.users_file, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                
                # expected: username,tty,login_time_iso,active_status
                parts = [p.strip() for p in line.split(",")]
                if len(parts) < 4:
                    continue
                    
                username, tty, login_time_iso, active = parts[:4]
                users.append({
                    "username": username,
                    "tty": tty,
                    "login_time_iso": login_time_iso,
                    "active": active.lower() == "true"
                })
        
        logging.info(f"Read {len(users)} users")
        return users

    def _read_jobs(self):
        """Read jobs from file"""
        jobs = []
        
        if not os.path.exists(self.jobs_file):
            logging.warning(f"Jobs file not found: {self.jobs_file}")
            return jobs
            
        with open(self.jobs_file, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                    
                # expected: id,name,owner,start_time_iso
                parts = [p.strip() for p in line.split(",")]
                if len(parts) < 4:
                    continue
                    
                jid, name, owner, start_time_iso = parts[:4]
                jobs.append({
                    "id": jid,
                    "name": name,
                    "owner": owner,
                    "start_time_iso": start_time_iso
                })
        
        logging.info(f"Read {len(jobs)} jobs")
        return jobs

    def _compute_runtime_seconds(self, start_iso: str) -> int:
        """Calculate runtime in seconds from start time"""
        try:
            start_dt = parse_iso_time(start_iso)
            delta = current_utc() - start_dt
            return max(0, int(delta.total_seconds()))
        except Exception:
            return 0

    # RPC implementations
    def ListUsers(self, request, context):
        """Returns list of currently logged-in users"""
        logging.info("ListUsers called")
        
        users = self._read_users()
        resp = monitoring_pb2.UsersResponse()
        
        for u in users:
            if u["active"]:
                user_msg = monitoring_pb2.User(
                    username=u["username"],
                    tty=u["tty"],
                    login_time_iso=u["login_time_iso"]
                )
                resp.users.append(user_msg)
        
        logging.info(f"Returning {len(resp.users)} active users")
        return resp

    def ListJobs(self, request, context):
        """Returns a stream of currently running jobs"""
        logging.info("ListJobs called")
        
        jobs = self._read_jobs()
        
        for j in jobs:
            runtime = self._compute_runtime_seconds(j["start_time_iso"])
            job_msg = monitoring_pb2.Job(
                id=j["id"],
                name=j["name"],
                owner=j["owner"],
                start_time_iso=j["start_time_iso"],
                runtime_seconds=runtime
            )
            yield job_msg
            time.sleep(0.1)  # Small delay for streaming effect
        
        logging.info(f"Streamed {len(jobs)} jobs")

    def GetLongestRunningJob(self, request, context):
        """Returns the job with maximum runtime"""
        logging.info("GetLongestRunningJob called")
        
        jobs = self._read_jobs()
        
        if not jobs:
            return monitoring_pb2.Job()
        
        best = None
        best_runtime = -1
        
        for j in jobs:
            runtime = self._compute_runtime_seconds(j["start_time_iso"])
            if runtime > best_runtime:
                best_runtime = runtime
                best = j
        
        if best is None:
            return monitoring_pb2.Job()
        
        logging.info(f"Longest job: {best['id']} with {best_runtime} seconds")
        
        return monitoring_pb2.Job(
            id=best["id"],
            name=best["name"],
            owner=best["owner"],
            start_time_iso=best["start_time_iso"],
            runtime_seconds=best_runtime
        )


def serve(port=50051):
    """Start the gRPC server"""
    server = grpc.server(futures.ThreadPoolExecutor(max_workers=10))
    
    monitoring_pb2_grpc.add_MonitoringServicer_to_server(
        MonitoringServicer(), server
    )
    
    server.add_insecure_port(f"0.0.0.0:{port}")
    server.start()
    
    # Log server information
    import socket
    hostname = socket.gethostname()
    ip_address = socket.gethostbyname(hostname)
    
    logging.info("=" * 50)
    logging.info("gRPC Monitoring Server Started")
    logging.info(f"Hostname: {hostname}")
    logging.info(f"IP Address: {ip_address}")
    logging.info(f"Port: {port}")
    logging.info(f"Users file: {USERS_FILE}")
    logging.info(f"Jobs file: {JOBS_FILE}")
    logging.info("=" * 50)
    
    try:
        while True:
            time.sleep(3600)
    except KeyboardInterrupt:
        logging.info("Server stopped")
        server.stop(0)


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    serve()



