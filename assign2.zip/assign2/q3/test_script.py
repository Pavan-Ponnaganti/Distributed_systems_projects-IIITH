# test_clients.py
import subprocess
import time
import os

CLIENT = "python client.py"
HOST = "localhost"
PORT = 50051

def run_client(rpc, log_file):
    with open(log_file, "w") as f:
        subprocess.Popen(
            f"{CLIENT} --host {HOST} --port {PORT} --rpc {rpc}",
            shell=True,
            stdout=f,
            stderr=subprocess.STDOUT
        )

def main():
    os.makedirs("client_logs", exist_ok=True)

    # Run multiple clients at once
    run_client("list_users", "client_logs/users.log")
    run_client("list_jobs", "client_logs/jobs.log")
    run_client("longest", "client_logs/longest.log")
    run_client("all", "client_logs/all.log")

    print("Clients started. Waiting for responses...")
    time.sleep(5)  # give clients time to finish

    print("\n=== OUTPUT COLLECTED ===")
    for file in os.listdir("client_logs"):
        print(f"\n--- {file} ---")
        with open(os.path.join("client_logs", file)) as f:
            print(f.read())

if __name__ == "__main__":
    main()
